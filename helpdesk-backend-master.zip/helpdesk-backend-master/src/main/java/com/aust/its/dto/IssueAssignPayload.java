package com.aust.its.dto;

public record IssueAssignPayload(
        long developerId
) { }
