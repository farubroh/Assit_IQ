package com.aust.its.enums;

public enum IssueStatus {
    PENDING,
    INPROGRESS,
    COMPLETED,
    REJECTED
}
