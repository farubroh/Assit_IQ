package com.aust.its.dto;

public record LoginPayload(
    String username,
    String password
) { }
